# Langboard app server SDK

Server-only signed archive delivery support. Requires Node 22.13+ and has no
third-party runtime dependency. Never expose this package or connection/provider
credentials to the browser. Node 22's built-in SQLite remains experimental.

`archiveReceiver({secret, store, host, resolveContext, execute, cardType, action})`
verifies exact signed bytes, checks current host receipts and explicitly enabled
app/board/connection/resource mappings, persists a claim before the provider
action and stores the exact outcome report. `resolveContext(event)` must return
trusted server configuration including `enabled: true`, `appKey`, `boardUID`,
`connectionUID` and `externalResourceId`; event fields are not configuration.
`execute(context)` performs provider-specific current-state readback and returns
an outcome such as `{state: 'applied', external_state: 'closed'}`.

`archiveHost({origin, token})` uses only a configured exact HTTPS native origin
and owning connection Bearer token. Reads and reports use the host archive API;
no redirects, credential discovery or automatic HTTP retries are performed.

`archiveStore(path)` is a small durable app-local SQLite operation ledger.
Keep it on persistent storage. It stores operation identity and reports, never
credentials. The receiver also accepts another store implementing synchronous
`claim(id,event)` and `record(id,report)` with atomic insert-if-absent semantics.
Claims without reports block another provider mutation and require explicit
operator reconciliation after a crash. A lost report response repeats the same
stored report only. Delivered webhooks and provider outcomes remain distinct.

The app owner supplies an HTTP endpoint, trusted mappings and feature settings.
Installing or declaring this package enables no workflow action. Package tests
are local contract evidence, not deployed provider or authorization acceptance.


## Explicit signal publication

`signalPublisher({origin, token}, request = fetch)` submits the host version-1
signal envelope using exact-byte timestamp HMAC and the native inbound credential.
Use an exact HTTPS origin. Redirects are rejected; no automatic retry is made.
Persist the normalized envelope before sending and explicitly reuse it after an
unknown response. Provider parsing and durable storage belong to the app. Current
declaration policy, consent, selected resources and revisions remain host checks.
Publication does not create cards, grant consent or change workflow.
Success requires a native `signal_uid` and a boolean `duplicate` receipt. An HTTP
success with a missing or malformed receipt has an unknown publication outcome;
retain the envelope and reconcile before explicitly resending it.
# Durable observation recovery

`signalStore(path, destination)` saves at most 25 envelopes to a new owner-only
file (64 KiB maximum), syncs the file and directory before publication, and
loads them after a process restart. Supply `origin`, `providerOrigin`, `boardUID`,
`resourceUID`, `appRevision` and `bindingRevision`. Recovery rejects changed
destinations or mappings, oversized batches and legacy unbound records.
Reconcile an old record manually; never infer its destination or re-read the
provider to replace it. Credentials must not be included in envelopes or files.
The store does not submit, retry or schedule work. After an unknown publication,
explicitly load and submit the same envelopes with `signalPublisher`; inspect
native receipts and current host authority before deciding to recover.

## App-card interaction requests

`cardInteractions({origin, token}, request = fetch)` exposes `create(boardUID,
cardUID, immutableRequest)` and `recover(boardUID, cardUID, immutableRequest)`.
Use the existing host interaction schema; semantic validation and current
ownership, policy, consent and workflow checks remain with the host. The client
bounds the JSON body and scope and verifies the returned immutable request.
The caller must persist the request before creation. A lost response is not
retried automatically: explicitly recover by its original `app_request_key` and
compare the request before deciding whether to submit again. A `missing` recovery
result is distinct from an HTTP failure. No response acceptance, provider action,
workflow transition or runtime continuation is performed by this client.


`interactionStore(path, {origin, providerOrigin, boardUID, cardUID, externalId})`
from the interaction subpath implements that durable storage. `save(record)`
accepts exactly one `{version: 1, board_uid, card_uid, request}` record, creates a
new owner-only file and syncs both file and directory. `load()` is bounded to
64 KiB and rejects changed host/provider/card/external identity. Repeated save
never overwrites pending work. Keep the file on persistent storage and inspect
an incomplete file after a crash; no automatic repair or submission is performed.
It uses the same bounded file implementation as signalStore, retaining the
existing signal file format. No database or third-party package is required for
this interaction subpath.


## Portable panel template packaging

`packagePanelTemplate({declaration, pythonSdk, output?, root?})` is exported from
`@langboard/app-server/packaging` (0.1.6). It packages apps that use the SDK's
`public/index.html`, `panel.mjs`, optional `inbox.mjs`, and light/dark SVG icon
template. Pass the app's explicit declaration and its pinned Python SDK wheel
or package directory. The native Python SDK validates and writes the deterministic
ZIP; this helper introduces no second archive format or JavaScript ZIP library.
Other panel layouts can use `python -m langboard_sdk.package` directly.

The helper copies into a temporary tree, rejects linked assets before rewrites,
rewrites template SDK imports to packaged relative modules and retains host.mjs
as the host-provided origin boundary. It does not alter source assets or include
the app server, dependencies, configuration secrets or provider tokens. Original
Python size, extension and hidden-file restrictions remain enforced. This build
API requires Python with the supplied SDK, Node and the installed panel package;
it does not install arbitrary executors or activate features. Optional app
profiles must be chosen before passing their declaration, and an external data
origin must identify the separately deployed service.

Loading server helpers no longer loads node:sqlite. Only constructing the legacy
`archiveStore` loads that local receipt implementation. Callers may supply their
own durable store through the existing archive receiver contract. Packaging,
signal publication and file-based interaction storage do not require SQLite.
