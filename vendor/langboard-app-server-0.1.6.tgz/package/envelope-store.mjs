import { open } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';

/** Shared bounded durable file, used by signal and interaction recovery. */
export function fileEnvelopeStore(path, destination, check) {
  return {
    async save(envelopes) {
      const body = JSON.stringify({ version: 1, destination, envelopes: check(envelopes) }) + '\n';
      if (Buffer.byteLength(body) > 65536) throw new Error('Observation exceeds storage limit');
      const file = await open(path, 'wx', 0o600);
      try { await file.writeFile(body); await file.sync(); } finally { await file.close(); }
      const directory = await open(dirname(resolve(path)), 'r');
      try { await directory.sync(); } finally { await directory.close(); }
    },
    async load() {
      const file = await open(path, 'r');
      let record;
      try {
        const stat = await file.stat();
        if (!stat.isFile() || !stat.size || stat.size > 65536) throw new Error('Invalid observation size');
        const buffer = Buffer.alloc(65537);
        const { bytesRead } = await file.read(buffer, 0, buffer.length, 0);
        if (bytesRead > 65536) throw new Error('Observation exceeds storage limit');
        record = JSON.parse(buffer.subarray(0, bytesRead).toString());
      } finally { await file.close(); }
      if (record?.version !== 1 || JSON.stringify(record.destination) !== JSON.stringify(destination)) {
        throw new Error('Observation destination changed or legacy record requires reconciliation');
      }
      return check(record.envelopes);
    },
  };
}
