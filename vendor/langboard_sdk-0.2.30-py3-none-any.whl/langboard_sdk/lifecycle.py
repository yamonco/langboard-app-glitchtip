"""Finite archive declarations; provider verbs stay in independent apps."""

import re
from copy import deepcopy


def validate_card_lifecycle(value):
    if not isinstance(value, dict) or not 1 <= len(value) <= 32:
        raise ValueError("Card lifecycle requires bounded card types")
    for key, policy in value.items():
        if not isinstance(key, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", key):
            raise ValueError("Invalid card type")
        if not isinstance(policy, dict) or set(policy) != {"archive", "restore"}:
            raise ValueError("Each card type requires archive and restore policies")
        archive = policy["archive"]
        if not isinstance(archive, dict) or archive.get("mode") not in ("retain", "external"):
            raise ValueError("Archive must explicitly retain or change external state")
        expected = {"mode", "description"} | ({"action", "default_enabled"} if archive["mode"] == "external" else set())
        if set(archive) != expected:
            raise ValueError("Invalid archive policy fields")
        if not isinstance(archive["description"], str) or not archive["description"].strip() or len(archive["description"]) > 1000:
            raise ValueError("Archive requires bounded explanatory text")
        if archive["mode"] == "external" and (
            not isinstance(archive["action"], str)
            or not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", archive["action"])
            or archive["default_enabled"] is not False
        ):
            raise ValueError("External archive requires a stable opt-in app action ID")
        if policy["restore"] != "retain_external_state":
            raise ValueError("Restore cannot implicitly reverse an external archive action")
    return deepcopy(value)
