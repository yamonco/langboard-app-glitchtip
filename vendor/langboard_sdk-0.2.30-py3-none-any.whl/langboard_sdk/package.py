"""Build a portable static panel ZIP with the standard library.

Usage: python -m langboard_sdk.package manifest.json panel-directory output.zip
The host supplies panel/host.mjs with its public UI origin after installation.
Server executors and secrets must never be placed in the static panel directory.
"""
import argparse
import json
import re
import stat
from pathlib import Path
from zipfile import ZIP_STORED, ZipFile, ZipInfo
from .definition import validate_app_definition

EXTENSIONS = {'.html', '.js', '.mjs', '.css', '.json', '.svg', '.png', '.jpg', '.jpeg', '.webp', '.gif', '.woff', '.woff2', '.txt', '.ico'}


def build_package(manifest_path: Path, panel_dir: Path, output: Path):
    manifest = json.loads(manifest_path.read_text())
    if (set(manifest) - {'package_version', 'declaration', 'panel_entry', 'store'} or not {'package_version', 'declaration', 'panel_entry'}.issubset(manifest)) or type(manifest['package_version']) is not int or manifest['package_version'] != 1:
        raise ValueError('Unsupported package manifest')
    validate_app_definition(manifest['declaration'])
    payloads = {'manifest.json': json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode()}
    for path in sorted(panel_dir.rglob('*')):
        if path.is_symlink():
            raise ValueError('Panel assets must not be symlinks')
        if path.is_dir():
            continue
        name = 'panel/' + path.relative_to(panel_dir).as_posix()
        if not path.is_file() or not re.fullmatch(r'[A-Za-z0-9_./-]{1,240}', name) or path.suffix.lower() not in EXTENSIONS or any(part.startswith('.') for part in path.relative_to(panel_dir).parts):
            raise ValueError('Only public static panel assets are allowed')
        if path.stat().st_size > 8 * 1024 * 1024:
            raise ValueError('Panel asset is too large')
        payloads[name] = path.read_bytes()
    if manifest['panel_entry'] not in payloads or not manifest['panel_entry'].startswith('panel/') or not manifest['panel_entry'].endswith('.html'):
        raise ValueError('Panel entry missing')
    store = manifest.get('store', {})
    if not isinstance(store, dict) or set(store) - {'icon', 'icon_dark', 'screenshots'} or not isinstance(store.get('screenshots', []), list) or len(store.get('screenshots', [])) > 5:
        raise ValueError('Invalid store metadata')
    for image in [store[key] for key in ('icon', 'icon_dark') if key in store] + store.get('screenshots', []):
        if not isinstance(image, str) or image not in payloads or Path(image).suffix.lower() not in {'.svg', '.png', '.jpg', '.jpeg', '.webp'}:
            raise ValueError('Store asset missing')
    if len(payloads) > 256 or sum(map(len, payloads.values())) > 8 * 1024 * 1024 - 65536:
        raise ValueError('Package exceeds installation limits')
    output.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(output, 'w', ZIP_STORED) as archive:
        for name, body in sorted(payloads.items()):
            entry = ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = (stat.S_IFREG | 0o644) << 16
            archive.writestr(entry, body)
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('panel_dir', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    build_package(args.manifest, args.panel_dir, args.output)
