"""Finite external signal semantics. A declaration is never an ingestion grant."""

import re
from copy import deepcopy
import hashlib
import hmac
import json
import time
from .management import _segment
from .rest import ApiTransport
from .client import MutationOutcomeUnknown


def validate_signal_policy(value, resource_types):
    fields = {"version", "event_types", "resource_types", "outcome_states", "commit_mode", "time_basis"}
    if not isinstance(value, dict) or set(value) != fields or type(value["version"]) is not int or value["version"] != 1:
        raise ValueError("Invalid signal policy schema")
    for field, pattern in (("event_types", r"[a-z][a-z0-9_.-]{0,63}"), ("resource_types", r"[a-z][a-z0-9_-]{0,63}")):
        items = value[field]
        if (not isinstance(items, list) or not 1 <= len(items) <= 16
            or any(not isinstance(item, str) or not re.fullmatch(pattern, item) for item in items)
            or len(set(items)) != len(items)):
            raise ValueError("Signal policy needs finite unique event/resource keys")
    if set(value["resource_types"]) - set(resource_types):
        raise ValueError("Signal resources must be declared by the app")
    outcomes = value["outcome_states"]
    if (not isinstance(outcomes, dict) or not 1 <= len(outcomes) <= 16
        or any(not isinstance(key, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", key)
               or not isinstance(state, str) or state not in {"passed", "failed", "resolved", "ignored", "queued", "running", "cancelled", "unknown"}
               for key, state in outcomes.items())):
        raise ValueError("Invalid finite signal outcome mapping")
    if value["commit_mode"] not in ("required", "empty", "optional") or value["time_basis"] not in ("provider_occurrence", "observation"):
        raise ValueError("Invalid signal commit/time semantics")
    return deepcopy(value)


class AppSignals:
    """Explicit signed publication. Caller owns credentials; no automatic retry."""

    def __init__(self, transport: ApiTransport, credential: str):
        if not isinstance(credential, str) or not re.fullmatch(r"lbac_[A-Za-z0-9_-]{43}", credential):
            raise ValueError("A native connection credential is required")
        self.transport, self._credential = transport, credential

    async def publish(self, board_uid: str, envelope: dict) -> dict:
        board = _segment(board_uid)
        fields = {"version", "board_uid", "resource_uid", "app_revision", "binding_revision",
                  "event_id", "event_type", "occurred_at", "external_id", "outcome", "commit_sha"}
        if (not isinstance(envelope, dict) or set(envelope) != fields or envelope["board_uid"] != board
            or type(envelope["version"]) is not int or envelope["version"] != 1):
            raise ValueError("Invalid signal envelope scope/schema")
        body = json.dumps(envelope, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
        if len(body) > 65536:
            raise ValueError("Signal envelope exceeds the byte limit")
        timestamp = str(int(time.time()))
        digest = hmac.new(self._credential.encode(), timestamp.encode() + b"." + body, hashlib.sha256).hexdigest()
        receipt = await self.transport.request("POST", f"/apps/v1/boards/{board}/signals", content=body, headers={
            "Authorization": "Bearer " + self._credential, "Content-Type": "application/json",
            "x-langboard-webhook-version": "1", "x-langboard-webhook-timestamp": timestamp,
            "x-langboard-webhook-signature": "v1=" + digest,
        })
        if (not isinstance(receipt, dict) or not isinstance(receipt.get("signal_uid"), str)
            or not re.fullmatch(r"[A-Za-z0-9]{1,11}", receipt["signal_uid"])
            or type(receipt.get("duplicate")) is not bool):
            raise MutationOutcomeUnknown("Signal publication receipt invalid; reconcile before explicit replay")
        return receipt
