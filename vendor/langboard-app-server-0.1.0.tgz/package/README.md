# Langboard app server SDK

Server-only signed archive delivery support. Requires Node 22.13+ and has no
third-party runtime dependency. Never expose this package or connection/provider
credentials to the browser. Node 22's built-in SQLite remains experimental.

`archiveReceiver({secret, store, host, resolveContext, execute, cardType, action})`
verifies exact signed bytes, checks current host receipts and explicitly enabled
app/board/connection/resource mappings, persists a claim before the provider
action and stores the exact outcome report. `resolveContext(event)` must return
trusted server configuration including `enabled: true`, `appKey`, `boardUID`,
`connectionUID` and `externalResourceId`; event fields are not configuration.
`execute(context)` performs provider-specific current-state readback and returns
an outcome such as `{state: 'applied', external_state: 'closed'}`.

`archiveHost({origin, token})` uses only a configured exact HTTPS native origin
and owning connection Bearer token. Reads and reports use the host archive API;
no redirects, credential discovery or automatic HTTP retries are performed.

`archiveStore(path)` is a small durable app-local SQLite operation ledger.
Keep it on persistent storage. It stores operation identity and reports, never
credentials. The receiver also accepts another store implementing synchronous
`claim(id,event)` and `record(id,report)` with atomic insert-if-absent semantics.
Claims without reports block another provider mutation and require explicit
operator reconciliation after a crash. A lost report response repeats the same
stored report only. Delivered webhooks and provider outcomes remain distinct.

The app owner supplies an HTTP endpoint, trusted mappings and feature settings.
Installing or declaring this package enables no workflow action. Package tests
are local contract evidence, not deployed provider or authorization acceptance.
