import { isDeepStrictEqual } from 'node:util';

/** Native immutable requests; unknown writes require explicit readback, never automatic replay. */
export function cardInteractions({ origin, token }, request = fetch) {
  const url = new URL(origin);
  if (url.protocol !== 'https:' || url.origin !== origin || typeof token !== 'string' ||
      !/^lbac_[A-Za-z0-9_-]{43}$/.test(token)) throw new Error('Exact HTTPS host and native connection credential required');
  const uid = value => typeof value === 'string' && /^[A-Za-z0-9]{11}$/.test(value);
  const prepare = (boardUID, cardUID, value) => {
    if (!uid(boardUID) || !uid(cardUID)) throw new Error('Invalid interaction scope');
    const body = JSON.stringify({ request: value });
    const frozen = JSON.parse(body).request;
    if (!frozen || Array.isArray(frozen) || frozen.schema_version !== 1 ||
        typeof frozen.app_request_key !== 'string' || !/^[a-z][a-z0-9_-]{0,63}$/.test(frozen.app_request_key) ||
        Buffer.byteLength(body) > 32768) throw new Error('Invalid interaction request');
    return { path: `/apps/v1/boards/${boardUID}/cards/${cardUID}/interactions`, body, frozen };
  };
  const call = async (method, prepared) => {
    const response = await request(origin + prepared.path, {
      method, ...(method === 'POST' ? { body: prepared.body } : {}),
      redirect: 'error', signal: AbortSignal.timeout(15000),
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    });
    if (!response.ok) throw new Error('Interaction request rejected');
    const receipt = await response.json();
    if (method === 'GET' && receipt?.state === 'missing' && receipt.request === null && receipt.response === null) return receipt;
    if (!receipt || !uid(receipt.interaction_uid) || !isDeepStrictEqual(receipt.request, prepared.frozen)) {
      throw new Error('Interaction outcome unknown: immutable request receipt mismatch');
    }
    return receipt;
  };
  return {
    create(boardUID, cardUID, value) { return call('POST', prepare(boardUID, cardUID, value)); },
    recover(boardUID, cardUID, value) {
      const prepared = prepare(boardUID, cardUID, value);
      prepared.path += '?app_request_key=' + encodeURIComponent(prepared.frozen.app_request_key);
      return call('GET', prepared);
    },
  };
}
