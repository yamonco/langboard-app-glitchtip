export { cardInteractions, interactionStore } from './interactions.mjs';
import { createHmac, timingSafeEqual } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { fileEnvelopeStore } from './envelope-store.mjs';

/** Durable explicit publication recovery; trust destinations cannot be retargeted. */
export function signalStore(path, { origin, providerOrigin, boardUID, resourceUID, appRevision, bindingRevision }) {
  const destination = { origin, providerOrigin, boardUID, resourceUID, appRevision, bindingRevision };
  for (const value of [origin, providerOrigin]) {
    const url = new URL(value);
    if (url.protocol !== 'https:' || url.origin !== value) throw new Error('Exact HTTPS observation origins required');
  }
  const check = envelopes => {
    if (!Array.isArray(envelopes) || envelopes.length > 25 || envelopes.some(value =>
      !value || value.board_uid !== boardUID || value.resource_uid !== resourceUID ||
      value.app_revision !== appRevision || value.binding_revision !== bindingRevision)) {
      throw new Error('Observation mapping changed');
    }
    return envelopes;
  };
  return fileEnvelopeStore(path, destination, check);
}

const uid = value => typeof value === 'string' && /^[A-Za-z0-9]{11}$/.test(value);
const eventType = 'io.langboard.app.card.archived.v1';

/** Publish one explicit observation; preserve its envelope after an unknown response. */
export function signalPublisher({ origin, token }, request = fetch) {
  const url = new URL(origin);
  if (url.protocol !== 'https:' || url.origin !== origin || typeof token !== 'string' ||
      !/^lbac_[A-Za-z0-9_-]{43}$/.test(token)) throw new Error('Exact HTTPS host and native connection credential required');
  return async envelope => {
    const fields = ['version', 'board_uid', 'resource_uid', 'app_revision', 'binding_revision',
      'event_id', 'event_type', 'occurred_at', 'external_id', 'outcome', 'commit_sha'];
    if (!envelope || Object.keys(envelope).length !== fields.length || fields.some(key => !Object.hasOwn(envelope, key)) ||
        envelope.version !== 1 || !uid(envelope.board_uid) || !uid(envelope.resource_uid) ||
        !['app_revision', 'binding_revision'].every(key => /^[0-9a-f]{64}$/.test(envelope[key])) ||
        !/^(?:[0-9a-f]{40}|[0-9a-f]{64})?$/.test(envelope.commit_sha) ||
        ![['event_id',128],['event_type',64],['occurred_at',40],['external_id',200],['outcome',64]].every(
          ([key,max]) => typeof envelope[key] === 'string' && envelope[key].trim() && envelope[key].length <= max)) throw new Error('Invalid signal envelope');
    const body = Buffer.from(JSON.stringify(envelope));
    if (body.length > 65536) throw new Error('Signal envelope too large');
    const timestamp = String(Math.floor(Date.now() / 1000));
    const signature = createHmac('sha256', token).update(timestamp + '.').update(body).digest('hex');
    const response = await request(`${origin}/apps/v1/boards/${envelope.board_uid}/signals`, {
      method: 'POST', body, redirect: 'error', signal: AbortSignal.timeout(15000),
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json',
        'x-langboard-webhook-version': '1', 'x-langboard-webhook-timestamp': timestamp,
        'x-langboard-webhook-signature': 'v1=' + signature },
    });
    if (!response.ok) throw new Error('Signal publication rejected');
    const receipt = await response.json();
    if (!receipt || typeof receipt.signal_uid !== 'string' || !/^[A-Za-z0-9]{1,11}$/.test(receipt.signal_uid) ||
        typeof receipt.duplicate !== 'boolean') throw new Error('Signal publication outcome unknown: invalid receipt');
    return receipt;
  };
}

/** App-local operation receipts survive restarts; no credentials are stored. */
export function archiveStore(path) {
  const db = new DatabaseSync(path);
  db.exec('CREATE TABLE IF NOT EXISTS archives (uid TEXT PRIMARY KEY, event TEXT NOT NULL, report TEXT)');
  return {
    claim(id, event) {
      const encoded = JSON.stringify(event);
      const inserted = db.prepare('INSERT OR IGNORE INTO archives(uid,event) VALUES (?,?)').run(id, encoded).changes === 1;
      const row = db.prepare('SELECT event,report FROM archives WHERE uid=?').get(id);
      if (row.event !== encoded) throw new Error('Archive identity conflict');
      return { inserted, report: row.report ? JSON.parse(row.report) : null };
    },
    record(id, report) { db.prepare('UPDATE archives SET report=? WHERE uid=? AND report IS NULL').run(JSON.stringify(report), id); },
    close() { db.close(); },
  };
}

export function verifyArchiveEvent(body, headers, secret, now = Math.floor(Date.now() / 1000)) {
  if (!Buffer.isBuffer(body) || body.length > 65536 || typeof secret !== 'string' || !secret) throw new Error('Invalid webhook');
  const timestamp = headers['x-langboard-webhook-timestamp'];
  const signature = headers['x-langboard-webhook-signature'];
  if (headers['x-langboard-webhook-version'] !== '1' || !/^[0-9]{1,12}$/.test(timestamp ?? '') ||
      !/^v1=[0-9a-f]{64}$/.test(signature ?? '') || now - Number(timestamp) > 300 || now - Number(timestamp) < -30) throw new Error('Invalid webhook');
  const expected = createHmac('sha256', secret).update(timestamp + '.').update(body).digest();
  if (!timingSafeEqual(expected, Buffer.from(signature.slice(3), 'hex'))) throw new Error('Invalid webhook');
  const event = JSON.parse(body.toString('utf8'));
  if (event.schema_version !== 1 || event.event_type !== eventType ||
      !['event_uid', 'archive_uid', 'board_uid', 'card_uid', 'connection_uid'].every(key => uid(event[key]))) throw new Error('Invalid archive event');
  return event;
}

/** Authenticated host calls use configured origin and token, never payload URLs. */
export function archiveHost({ origin, token }, request = fetch) {
  const url = new URL(origin);
  if (url.protocol !== 'https:' || url.origin !== origin || url.username || url.password || !token) throw new Error('Exact HTTPS host origin and credential required');
  const call = async (event, method, report) => {
    const path = `/apps/v1/boards/${event.board_uid}/archives/${event.archive_uid}${method === 'POST' ? '/outcome' : ''}`;
    const response = await request(origin + path, { method, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      ...(report ? { body: JSON.stringify(report) } : {}), redirect: 'error', signal: AbortSignal.timeout(15000) });
    if (!response.ok) throw new Error('Current host authority or report unavailable');
    return await response.json();
  };
  return { read: event => call(event, 'GET'), report: (event, report) => call(event, 'POST', report) };
}

/** Caller supplies a trusted mapping and provider action; the SDK never interprets provider IDs. */
export function archiveReceiver({ secret, store, host, resolveContext, execute, cardType, action }) {
  return async (body, headers) => {
    const event = verifyArchiveEvent(body, headers, secret);
    if (event.card_type !== cardType || event.action !== action) throw new Error("Unsupported archive action");
    const context = await resolveContext(event);
    if (!context || context.enabled !== true || context.appKey !== event.app_key || context.boardUID !== event.board_uid ||
        context.connectionUID !== event.connection_uid || context.externalResourceId !== event.external_resource_id) throw new Error('Archive feature or mapping unavailable');
    const current = await host.read(event);
    const receipt = current.receipt;
    if (current.archive_uid !== event.archive_uid || receipt?.event_uid !== event.event_uid || receipt.connection_uid !== event.connection_uid ||
        receipt.card_type !== cardType || receipt.external_resource_id !== event.external_resource_id ||
        receipt.archive_policy?.action !== action || !Number.isSafeInteger(receipt.outcome_revision)) throw new Error('Current archive identity mismatch');
    const claim = store.claim(event.archive_uid, event);
    if (['applied', 'already_applied'].includes(receipt.state)) return { state: receipt.state, changed: false };
    if (receipt.provider_report && !claim.report) return { state: receipt.state, changed: false };
    if (receipt.state !== 'pending' && !claim.report) throw new Error('Archive reconciliation required');
    let report = claim.report;
    if (!claim.inserted && !report) return { state: 'processing', changed: false };
    if (!report) {
      // A crash or concurrent claim after persistence must never repeat a provider mutation.
      const outcome = await execute(context);
      report = { expected_revision: receipt.outcome_revision, outcome: {
        state: outcome.state, external_state: outcome.external_state ?? null,
        readback_confirmed: ['applied', 'already_applied'].includes(outcome.state),
      } };
      store.record(event.archive_uid, report);
    }
    // A lost report response only replays the same durable report, not the provider action.
    return await host.report(event, report);
  };
}
